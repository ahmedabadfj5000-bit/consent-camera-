const express = require("express");
const multer = require("multer");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const WEBHOOK_URL = process.env.DISCORD_WEBHOOK_URL;

if (!WEBHOOK_URL || !/^https:\/\/discord\.com\/api\/webhooks\//.test(WEBHOOK_URL)) {
  console.error("Set DISCORD_WEBHOOK_URL to your Discord webhook URL.");
  process.exit(1);
}

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 5 * 1024 * 1024, files: 1 },
  fileFilter: (_req, file, cb) => {
    cb(null, ["image/jpeg", "image/png", "image/webp"].includes(file.mimetype));
  }
});

app.use(express.static(path.join(__dirname, "public")));

app.post("/api/photo", upload.single("photo"), async (req, res) => {
  try {
    if (req.body.consent !== "yes" || !req.file) {
      return res.status(400).json({ error: "Consent and a photo are required." });
    }

    const form = new FormData();
    form.append("payload_json", JSON.stringify({
      content: "A visitor voluntarily submitted a photo through the consent camera page."
    }));
    const blob = new Blob([req.file.buffer], { type: req.file.mimetype });
    form.append("files[0]", blob, "visitor-photo." + (
      req.file.mimetype === "image/png" ? "png" :
      req.file.mimetype === "image/webp" ? "webp" : "jpg"
    ));

    const response = await fetch(WEBHOOK_URL, { method: "POST", body: form });
    if (!response.ok) {
      console.error("Discord returned:", response.status);
      return res.status(502).json({ error: "Discord could not accept the photo." });
    }
    res.json({ ok: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Upload failed." });
  }
});

app.listen(PORT, () => console.log(`Open http://localhost:${PORT}`));
